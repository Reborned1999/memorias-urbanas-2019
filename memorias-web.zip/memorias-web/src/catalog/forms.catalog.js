const places = [
  {
    key: 0,
    id: 'name',
    label: 'Nombre',
    type: 'text'
  },
  {
    key: 1,
    id: 'description',
    label: 'Descripcion',
    type: 'text'
  },
  {
    key: 11,
    id: 'style',
    label: 'Estilo',
    type: 'text'
  },
  {
    key: 2,
    id: 'street',
    label: 'Calle',
    type: 'text'
  },{
    key: 3,
    id: 'avenue',
    label: 'Avenida',
    type: 'text'
  },
  {
    key: 4,
    id: 'year',
    label: 'Año',
    type: 'number'
  },
  {
    key: 5,
    id: 'owner',
    label: 'Dueño',
    type: 'text'
  },
  {
    key: 6,
    id: 'lat',
    label: 'Latitud',
    type: 'number'
  },
  {
    key: 7,
    id: 'lon',
    label: 'Longitud',
    type: 'number'
  },
  {
    key: 8,
    id: 'function',
    label: 'Funcionamiento',
    type: 'text'
  },
  {
    key: 9,
    id: 'form-category',
    label: 'Categoria',
    type: 'select'
  },
  {
    key: 10,
    id: 'images',
    label: 'Imagenes',
    type: 'file'
  },
]

const categories = [
  {
    key: 0,
    value: 'all',
    label: 'Todos'
  },
  {
    key: 1,
    value: 'academic',
    label: 'Academico'
  },
  {
    key: 2,
    value: 'art',
    label: 'Arte'
  },
  {
    key: 3,
    value: 'coffe',
    label: 'Cafe - Restaurante'
  },
  {
    key: 4,
    value: 'hotel',
    label: 'Hotel'
  },
]

export { places, categories }