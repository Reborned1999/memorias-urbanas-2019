import firebase from 'firebase/app'
import 'firebase/firestore'
import 'firebase/storage' 

// Initialize Firebase
var config = {
  apiKey: "AIzaSyCCv_AoA5TlhyjAf6KypWFBoBbzX5IvD68",
  authDomain: "itcr-memorias.firebaseapp.com",
  databaseURL: "https://itcr-memorias.firebaseio.com",
  projectId: "itcr-memorias",
  storageBucket: "itcr-memorias.appspot.com",
  messagingSenderId: "882624796390"
}

firebase.initializeApp(config)

const storage = firebase.storage()

export { storage, firebase }