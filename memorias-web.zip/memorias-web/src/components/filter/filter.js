import React from 'react'
import MenuItem from '@material-ui/core/MenuItem'
import FormControl from '@material-ui/core/FormControl'
import Select from '@material-ui/core/Select'
import './filter.css'

const Filter = ({ handleChange, selected, filterElems }) => {
  return(
    <FormControl classes={{root:"filter"}}>
      <Select
        value={selected}
        onChange={handleChange}
        inputProps={{
          name: 'category',
          id: 'category',
        }}
        classes={{
          root: 'filter__root',
          icon: 'filter__icon'
        }}
        variant='outlined'
      >
        {filterElems.map(category => 
          <MenuItem key={category.key} value={category.label}>{category.label}</MenuItem> 
        )}
      </Select>
    </FormControl>
  )
}

export default Filter