import React, { Component } from 'react'
import CustomButton from '../button/button'
import { storage, firebase } from '../../config/firebase.config'
import { places } from '../../catalog/forms.catalog'
import './placeForm.css'

class PlaceForm extends Component {

  state = {
    images: [],
  }

  handleFormSubmit = async event => {
    event.preventDefault()
    const { changeDialogState } = this.props
    const urls = await this.handleImagesUpload()
    const placeData = {
      name: document.getElementById('name').value,
      description: document.getElementById('description').value,
      street: document.getElementById('street').value,
      avenue: document.getElementById('avenue').value,
      year: document.getElementById('year').value,
      owner: document.getElementById('owner').value,
      function: document.getElementById('function').value,
      lat: document.getElementById('lat').value,
      lon: document.getElementById('lon').value,
      category: document.getElementById('form-category').value,
      buildingStyle: document.getElementById('style').value,
      images: urls
    }
    const db = firebase.firestore()
    db.collection('places').add(placeData)
    .then(function(docRef) {
      changeDialogState()
    })
    .catch(function(error) {
        console.error("Error adding document: ", error);
    });
  }


  handleImagesUpload = async () => {
    const { images } = this.state
    const urls = []
    for(let i = 0; i < images.length; i++) {
      await storage.ref(`images/${images[i].name}`).put(images[i])
      await storage.ref('images').child(images[i].name).getDownloadURL().then(url => {
        urls.push(url)
      }).catch(err => {
        console.log(err)
      })
    }
    return urls
  }

  handleInputFileChange = e => {
    if (e.target.files[0]) {
      const images = e.target.files
      this.setState({
        images: images
      })
    }
  }

  getFormInput = item => {
    if (item.type === 'file') {
      return <input 
        key={'input'+item.key}
        className="place-form__inputs__input"
        id={item.id} type="file" accept="image/*"
        onChange={this.handleInputFileChange}
        required
        multiple
      />
    } else if (item.type === 'number') {
      return <input key={'input'+item.key} className="place-form__inputs__input" id={item.id} type={item.type} step='any' required/> 
    } else if (item.type === 'select') {
      return (
        <select key={'input'+item.key} id={item.id}>
          <option value="academic">Academico</option>
          <option value="art">Arte</option>
          <option value="coffe">Cafe - Restaurante</option>
          <option value="hotel">Hotel</option>
        </select>
      )
    } else {
      return <input key={'input'+item.key} className="place-form__inputs__input" id={item.id} type={item.type} required/> 
    }
  }

  render() {
    return (
      <div>
        <form className="place-form" onSubmit={this.handleFormSubmit}>
          <div className="place-form__labels">
            {places.map(item => 
              <label key={'label'+item.key} className="place-form__labels__label">{item.label}:</label>          
            )}
          </div>
          <div className="place-form__inputs">
            {places.map(item => this.getFormInput(item))}       
          </div>
          <div className="place-form__btn">
            <CustomButton btnType="submit" variant="contained" color="primary" label="Guardar Lugar"/>
          </div>
        </form>
      </div>
    )
  }
}

export default PlaceForm