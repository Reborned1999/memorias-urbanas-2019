import React from 'react'
import SearchIcon from '../../assets/search.svg'
import './search.css'

const Search = () => {
  return(
    <div className="search">
      <img className="search__icon" src={SearchIcon} alt="search icon"/>
      <input className="search__input" type='text' />
    </div>
  )
}

export default Search