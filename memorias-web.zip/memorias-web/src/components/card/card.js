import React from 'react'
import EditIcon from '../../assets/edit.svg'
import DeleteIcon from '../../assets/delete.svg'
import './card.css'

const PlaceCard = ({ placeData, placeId, deletePlace }) => {
  return(
    <div className="place-card">
      <div className="place-card__img">
        <img className="place-card__img__src" src={placeData.images[0]} alt="place"/>
      </div>
      <div className="place-card__info">
        <h3>{ placeData.name }</h3>
        <h4>{ placeData.buildingStyle + ' - ' + placeData.year }</h4>
      </div>
      <div className="place-card__actions">
        <div className="place-card__actions__btns">
          <div className="card-btn" onClick={() => {}}>
            <img className="card-btn__icon" src={EditIcon} alt="edit"/>
          </div>
          <div className="card-btn" onClick={() => deletePlace(placeId)}>
            <img className="card-btn__icon" src={DeleteIcon} alt="edit"/>
          </div>
        </div>
      </div>
    </div>
  )
}



export default PlaceCard