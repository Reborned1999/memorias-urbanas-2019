import React from 'react'
import Button from '@material-ui/core/Button'

const CustomButton = ({ label, clickAction, btnType }) => {
  return(
    <Button type={btnType} variant="contained" color="primary" onClick={clickAction}>
      {label}
    </Button>
  )
}

export default CustomButton