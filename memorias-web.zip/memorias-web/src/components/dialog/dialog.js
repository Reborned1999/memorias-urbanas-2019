import React from 'react'
import Button from '@material-ui/core/Button'
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import PlaceForm from '../placeForm/placeForm'

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

const CustomDialog = ({ dialogOpen, changeDialogState}) => {
  return(
    <Dialog
      open={dialogOpen}
      onClose={changeDialogState}
      TransitionComponent={Transition}
      aria-labelledby="form-dialog-title"
    >
      <DialogTitle id="form-dialog-title">Informacion de lugar</DialogTitle>
      <DialogContent>
        <PlaceForm changeDialogState={changeDialogState}/>
      </DialogContent>
      <DialogActions>
        <Button onClick={changeDialogState} color="primary">
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  )
}

export default CustomDialog