import React, { Component } from 'react'
import Search from '../../components/search/search'
import { firebase } from '../../config/firebase.config'
import { categories } from '../../catalog/forms.catalog'
import Filter from '../../components/filter/filter'
import CustomDialog from '../../components/dialog/dialog'
import PlaceCard from '../../components/card/card'
import './main.css'


class MainPage extends Component {

  /* Page state */
  state = {
    category: 'Todos',
    placeFormOpen: false,
    places: []
  }

  /* Methods triggers when react component has been built */
  componentDidMount = () => {
    this.getPlaces()
  }

  /* Handles the change of state for components at 'this.state' */
  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  }

  /* Handles refresh action */
  handleRefresh = () => {
    /* Pull data from DB... */
  }

  /* Handles change in place form */
  handlePlaceFormView = () => {
    const { placeFormOpen } = this.state
    this.setState({ placeFormOpen: !placeFormOpen })
  }

  /* Get places data from firebase DB */
  getPlaces = async () => {
    const newPlaces = []
    const db = firebase.firestore()
    await db.collection("places").get()
    .then(async function(querySnapshot) {
      await querySnapshot.forEach(async function(doc) {
        await newPlaces.push({
          id: doc.id,
          data: doc.data()
        })
      });
    })
    .catch(function(error) {
        console.log("Error getting places: ", error);
    });
    this.setState({
      places: newPlaces
    })
  }

  /* Deletes place data from firebase DB */
  deletePlace = placeId => {
    const db = firebase.firestore()
    db.collection("places").doc(placeId).delete()
    .then(this.getPlaces())
    .catch(function(error) {
        console.log("Error deleting place: ", error);
    });
  }

  /* Rendering method */
  render() {

      const { category, places, placeFormOpen } = this.state

    return(
      <div className="page">
        <header className="page__header">
          <h1 className="page__header__title">Memorias Urbanas</h1>
          <div className="header__btns">
            <button className="custom__btn" type='button' onClick={this.getPlaces}>Refrescar</button>
            <button className="custom__btn" type='button' onClick={this.handlePlaceFormView}>Agregar</button>
          </div>
        </header>
        <div className="page__body">
          {
            places.map(p => 
              <PlaceCard key={p.id} placeData={p.data} placeId={p.id} deletePlace={this.deletePlace}/>
            )
          }
        </div>
        <CustomDialog dialogOpen={placeFormOpen} changeDialogState={this.handlePlaceFormView}/>
      </div>
    )
  }
}

/* <Search />
<h3 className="page__header__subtitle">Mostrando: </h3>
<Filter handleChange={this.handleChange} selected={category} filterElems={categories}/> */

export default MainPage